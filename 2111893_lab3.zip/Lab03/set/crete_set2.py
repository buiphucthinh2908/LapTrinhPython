# Tạo một Tập hợp (Set) bằng cách
# sử dụng một Danh sách các số
# (Có giá trị trùng lặp)
set1 = set([1, 2, 4, 4, 3, 3, 3, 6, 5])
print("\nTập hợp được tạo bằng cách sử dụng các số: ")
print(set1)

# Tạo một Tập hợp (Set) bằng cách
# sử dụng các loại giá trị kết hợp
# (Bao gồm số và chuỗi)
set1 = set([1, 2, 'Geeks', 4, 'For', 6, 'Geeks'])
print("\nTập hợp được tạo bằng cách sử dụng các giá trị kết hợp")
print(set1)
