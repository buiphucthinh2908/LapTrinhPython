

#Nhập mô đun vào mảng
import array as arr

# mảng có kiểu dữ liệu là int
a = arr.array('i', [1, 2, 3, 4, 5, 6])

# truy cập phần tử của mảng
print("Lấy giá trị phần tử: ", a[0])

# Truy cập phần tử trong mảng
print("Lấy giá trị phần tử: ", a[3])

# Mảng với kiểu float
b = arr.array('d', [2.5, 3.2, 3.3])

# Truy cập phần tử trong mảng
print("Lấy giá trị phần tử: ", b[1])

# Truy cập phần tử của mảng
print("Lấy giá trị phần tử: ", b[2])
