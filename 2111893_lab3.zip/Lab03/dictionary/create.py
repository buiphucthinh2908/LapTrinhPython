# Tạo một Từ điển (Dictionary)
# với các khóa kiểu số nguyên
Dict = {1: 'Geeks', 2: 'For', 3: 'Geeks'}
print("\nTừ điển sử dụng các khóa kiểu số nguyên: ")
print(Dict)

# Tạo một Từ điển (Dictionary)
# với các khóa kết hợp kiểu dữ liệu
Dict = {'Name': 'Geeks', 1: [1, 2, 3, 4]}
print("\nTừ điển sử dụng các khóa kết hợp kiểu dữ liệu: ")
print(Dict)

# Tạo một Từ điển (Dictionary)
# bằng cách sử dụng phương thức dict()
Dict = dict({1: 'Geeks', 2: 'For', 3: 'Geeks'})
print("\nTừ điển sử dụng phương thức dict(): ")
print(Dict)

# Tạo một Từ điển (Dictionary)
# với mỗi phần tử là một cặp
Dict = dict([(1, 'Geeks'), (2, 'For')])
print("\nTừ điển với mỗi phần tử là một cặp: ")
print(Dict)
