# Truy cập Tuple
# thông qua chỉ mục (index)
Tuple1 = tuple("Geeks")
print("\nPhần tử đầu tiên của Tuple: ")
print(Tuple1[0])

# Giải nén Tuple
Tuple1 = ("Geeks", "For", "Geeks")

# Dòng này giải nén
# các giá trị của Tuple1
a, b, c = Tuple1
print("\nCác giá trị sau khi giải nén: ")
print(a)
print(b)
print(c)
