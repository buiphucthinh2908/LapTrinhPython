# Cắt một Tuple

# Cắt một Tuple
# với các số
Tuple1 = tuple('GEEKSFORGEEKS')

# Loại bỏ phần tử đầu tiên
print("Loại bỏ phần tử đầu tiên: ")
print(Tuple1[1:])

# Đảo ngược Tuple
print("\nTuple sau khi đảo ngược: ")
print(Tuple1[::-1])

# In các phần tử trong một phạm vi
print("\nIn các phần tử trong phạm vi từ 4-9: ")
print(Tuple1[4:9])
