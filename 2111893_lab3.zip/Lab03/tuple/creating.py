# Tạo một Tuple rỗng mới
Tuple1 = ()
print("Tuple rỗng ban đầu: ")
print(Tuple1)

# Tạo một Tuple
# bằng cách sử dụng chuỗi
Tuple1 = ('Geeks', 'For')
print("\nTuple được tạo bằng cách sử dụng Chuỗi: ")
print(tuple(Tuple1))
 
# Tạo một Tuple bằng cách
# sử dụng danh sách (list)
list1 = [1, 2, 4, 5, 6]
print("\nTuple được tạo bằng cách sử dụng Danh sách: ")
print(tuple(list1))
 
# Tạo một Tuple
# bằng cách sử dụng hàm tích hợp sẵn
Tuple1 = tuple('Geeks')
print("\nTuple được tạo bằng cách sử dụng hàm: ")
print(Tuple1)
