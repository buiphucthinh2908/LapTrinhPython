# Nối các tuple lại với nhau
Tuple1 = (0, 1, 2, 3)
Tuple2 = ('Geeks', 'For', 'Geeks')

Tuple3 = Tuple1 + Tuple2

# In ra Tuple đầu tiên
print("Tuple 1: ")
print(Tuple1)

# In ra Tuple thứ hai
print("\nTuple2: ")
print(Tuple2)

# In ra Tuple cuối cùng sau khi nối
print("\nTuples sau khi nối: ")
print(Tuple3)
